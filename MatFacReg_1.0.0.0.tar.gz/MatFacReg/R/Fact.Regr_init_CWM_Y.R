#' Initialization for Matrix-Variate Cluster-Weighted Bilinear Factor Analyzers with Parsimony on Y
#'
#' Initializes the AECM algorithm for fitting Matrix-Variate Cluster-Weighted Bilinear Factor Analyzers, with parsimonious covariance modeling on Y.
#' Supports parallel computing, which is highly recommended.
#'
#' @param Y An array with dimensions \code{p} x \code{r} x \code{num}, where \code{p} is the number of
#'     variables in the rows of each data matrix, \code{r} is the number of variables in the columns of each
#'     data matrix, and \code{num} is the number of data observations.
#' @param X Y An array with dimensions \code{q} x \code{r} x \code{num}, where \code{q} is the number of
#'     covariates in the rows of each data matrix, \code{r} is the number of variables in the columns of each
#'     data matrix, and \code{num} is the number of data observations.
#' @param k An integer or vector of the form (1:k) indicating the number of clusters in the model(s).
#' @param fc1 An integer or vector of the form (1:fc1) indicating the number of row factors.
#' @param fc2 An integer or vector of the form (1:fc2) indicating the number of columns factors.
#' @param seed A positive integer specifying the seed for random generation.
#' @param nstartR An integer specifying the number of random starts to consider.
#' @param nThreads A positive integer indicating the number of cores to use for parallel processing.
#'
#' @return A list containing the following elements:
#' \item{model}{The acronym used for the fixed covariates family of models.}
#' \item{results}{A list of the results from the initialization.}
#' \item{k}{The number of clusters fitted in each model.}
#' \item{fc1}{The number of row factors fitted in each model.}
#' \item{fc2}{The number of columns factors fitted in each model.}
#' @export
#' @importFrom foreach %dopar%
Fact.CWM.Y_init <- function(Y, X, k, fc1, fc2, seed = 1, nstartR = 50, nThreads = 14) {
  r_Pars_init <- function(Y, X, k, fc1, fc2, seed = NULL, nstartR = 50) {
    tr <- function(x) {
      return(sum(diag(x)))
    }

    # Dimensions

    num <- dim(X)[3] # sample size
    p <- nrow(Y) # rows of Y ; rows of Theta
    r <- ncol(Y) # columns of Y; columns of X
    q <- nrow(X) + 1 # columns of Theta; rows of X
    Q <- nrow(X)

    # Add intercept to X

    unos <- rep(1, r)
    X1 <- array(0, dim = c(q, r, num))
    for (i in 1:num) {
      X1[, , i] <- rbind(unos, X[, , i])
    }

    # Attach Y and X by rows

    XY <- array(0, dim = c((p + q - 1), r, num)) # metto il -1 per togliere la riga di 1 intercetta

    for (i in 1:num) {
      XY[, , i] <- rbind(Y[, , i], X[, , i])
    }

    # Create some objects

    prior <- matrix(NA, nstartR, k)
    llk <- rep(NA, nstartR)

    coeff <- array(0, dim = c(p, q, k, nstartR))
    M     <- array(0, dim = c(Q, r, k, nstartR))

    sigmaU <- sigmaU.dg <- array(0, dim = c(p, p, k, nstartR))
    sigmaV <- sigmaV.dg <- array(0, dim = c(r, r, k, nstartR))
    sigmaUX <- array(0, dim = c(Q, Q, k, nstartR))
    sigmaVX <- array(0, dim = c(r, r, k, nstartR))

    WR <- array(0, dim = c(p, p, k))
    WC <- array(0, dim = c(r, r, k))
    WRX <- array(0, dim = c(Q, Q, k))
    WCX <- array(0, dim = c(r, r, k))

    lambdaU.ini <- array(0, dim = c(p, fc1, nstartR))
    lambdaV.ini <- array(0, dim = c(r, fc2, nstartR))

    lambdaU <- array(0, dim = c(p, fc1, k, nstartR))
    lambdaV <- array(0, dim = c(r, fc2, k, nstartR))

    sel <- array(0, dim = c(p + q - 1, r, k))

    dens <- array(0, c(num, k), dimnames = list(1:(num), paste("comp.", 1:k, sep = "")))

    ## Random initialization ##

    eu <- matrix(0, nrow = num, ncol = k)
    classy <- numeric(num)
    rand.start <- matrix(0, nstartR, k)

    withr::with_seed(seed, for (i in 1:nstartR) {
      rand.start[i, ] <- sample(c(1:num), k)

      lambdaU.ini[, , i] <- stats::runif(p * fc1, -1, 1)
      lambdaV.ini[, , i] <- stats::runif(r * fc2, -1, 1)
    })

    for (t in 1:nstartR) {

      skip_to_next <- FALSE

      ### part 0 ###

      tryCatch(
        {

          sec <- rand.start[t, ]

          for (j in 1:k) {
            sel[, , j] <- XY[, , sec[j]]
          }

          for (j in 1:k) {
            for (i in 1:(num)) {
              eu[i, j] <- norm((XY[, , i] - sel[, , j]), type = "F")
            }
          }

          for (i in 1:(num)) {
            classy[i] <- which.min(eu[i, ])
          }

          z <- mclust::unmap(classy)

          ### part 1 ###

          for (j in 1:k) {

            tempcoeff1 <- tensor::tensor(aperm(tensor::tensor(Y * z[, j][slice.index(Y, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm(X1, c(2, 1, 3)), c(2, 3), c(1, 3))
            tempcoeff2 <- tensor::tensor(aperm(tensor::tensor(X1 * z[, j][slice.index(X1, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm(X1, c(2, 1, 3)), c(2, 3), c(1, 3))

            coeff[, , j, t] <- tempcoeff1 %*% solve(tempcoeff2)

            BX <- tensor::tensor(coeff[, , j, t], X1, 2, 1)

            WR[, , j] <- tensor::tensor(aperm(tensor::tensor((Y - BX) * z[, j][slice.index(Y - BX, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm((Y - BX), c(2, 1, 3)), c(2, 3), c(1, 3))
            WC[, , j] <- tensor::tensor(aperm(tensor::tensor(aperm(Y - BX, c(2, 1, 3)) * z[, j][slice.index(aperm(Y - BX, c(2, 1, 3)), 3)], solve(diag(p)), 2, 1), c(1, 3, 2)), (Y - BX), c(2, 3), c(1, 3))

            # X #

            M[, , j, t] <- rowSums(X * z[, j][slice.index(X, 3)], dims = 2) / sum(z[, j])
            Mtemp <- array(M[, , j, t], dim = c(Q, r, num))

            WRX[, , j] <- tensor::tensor(aperm(tensor::tensor((X - Mtemp) * z[, j][slice.index(X - Mtemp, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm((X - Mtemp), c(2, 1, 3)), c(2, 3), c(1, 3))
            WCX[, , j] <- tensor::tensor(aperm(tensor::tensor(aperm(X - Mtemp, c(2, 1, 3)) * z[, j][slice.index(aperm(X - Mtemp, c(2, 1, 3)), 3)], solve(diag(Q)), 2, 1), c(1, 3, 2)), (X - Mtemp), c(2, 3), c(1, 3))
            sigmaUX[, , j, t] <- WRX[, , j] / (r * sum(z[, j]))
            sigmaVX[, , j, t] <- WCX[, , j] / (Q * sum(z[, j]))

          }

          phiR <- tr(rowSums(WR, dims = 2)) / (num * p * r)
          phiC <- tr(rowSums(WC, dims = 2)) / (num * p * r)

          for (j in 1:k) {
            lambdaU[, , j, t] <- lambdaU.ini[, , t]
            lambdaV[, , j, t] <- lambdaV.ini[, , t]

            sigmaU.dg[, , j, t] <- phiR * diag(1, p, p)
            sigmaV.dg[, , j, t] <- phiC * diag(1, r, r)

            sigmaU[, , j, t] <- sigmaU.dg[, , j, t] + (lambdaU[, , j, t] %*% t(lambdaU[, , j, t]))
            sigmaV[, , j, t] <- sigmaV.dg[, , j, t] + (lambdaV[, , j, t] %*% t(lambdaV[, , j, t]))

            for (i in 1:num) {
              dens[i, j] <- dMVnorm(X = Y[, , i], M = coeff[, , j, t] %*% X1[, , i], U = sigmaU[, , j, t], V = sigmaV[, , j, t])*
                dMVnorm(X = X[, , i], M = M[, , j, t], U = sigmaUX[, , j, t], V = sigmaVX[, , j, t])

              dens[i, j] <- (dens[i, j] <= 10^(-323)) * 10^(-323) + (dens[i, j] > 10^(-323)) * dens[i, j]

            }
          }

          if (k == 1) {
            prior[t, ] <- 1
          } else {
            prior[t, ] <- colMeans(z)
          }

          ### part 2 ###

          # mixture density

          numerator <- matrix(rep(prior[t, ], num), num, k, byrow = TRUE) * dens
          mixt.dens <- rowSums(numerator)
          llk[t] <- sum(log(mixt.dens))

          if (any(prior[t, ] <= 0.05)) {
            llk[t] <- NA
          }
        },
        error = function(e) {
          skip_to_next <<- TRUE
        }
      )

      if (skip_to_next) {
        next
      }

    }

    df <- data.frame(llk = llk, pos = c(1:nstartR))
    df <- tidyr::drop_na(df)
    df <- df[!is.infinite(rowSums(df)), ]
    bestR <- utils::head(data.table::setorderv(df, cols = "llk", order = -1), n = 1)$pos

    return(list(prior = prior[bestR, ],
                coeff = array(coeff[, , , bestR], dim = c(p, q, k)), sigmaU = array(sigmaU[, , , bestR], dim = c(p, p, k)), sigmaV = array(sigmaV[, , , bestR], dim = c(r, r, k)),
                sigmaU.dg = array(sigmaU.dg[, , , bestR], dim = c(p, p, k)), sigmaV.dg = array(sigmaV.dg[, , , bestR], dim = c(r, r, k)),
                lambdaU = array(lambdaU[, , , bestR], dim = c(p, fc1, k)), lambdaV = array(lambdaV[, , , bestR], dim = c(r, fc2, k)),
                M = array(M[, , , bestR], dim = c(Q, r, k)), sigmaUX = array(sigmaUX[, , , bestR], dim = c(Q, Q, k)), sigmaVX = array(sigmaVX[, , , bestR], dim = c(r, r, k)),
                llk = llk[bestR]
    ))
  }
  l <- NULL

  comb <- function(x, ...) {
    lapply(
      seq_along(x),
      function(i) c(x[[i]], lapply(list(...), function(y) y[[i]]))
    )
  }

  k.mod <- k
  fc1.mod <- fc1
  fc2.mod <- fc2

  list.comb <- expand.grid(fc1.mod, fc2.mod, k.mod)

  cluster <- snow::makeCluster(nThreads, type = "SOCK")
  doSNOW::registerDoSNOW(cluster)

  pb <- progress::progress_bar$new(
    format = "(:spin) [:bar] :percent [Elapsed time: :elapsedfull || Estimated time remaining: :eta]",
    total = nrow(list.comb),
    complete = "=", # Completion bar character
    incomplete = "-", # Incomplete bar character
    current = ">", # Current bar character
    width = 100
  )
  progress <- function(n) {
    pb$tick()
  }
  opts <- list(progress = progress)

  results <- foreach::foreach(l = 1:nrow(list.comb), .combine = "comb", .multicombine = TRUE, .init = list(list()), .options.snow = opts) %dopar% {
    res <- r_Pars_init(Y = Y, X = X, k = list.comb[l, 3], fc1 = list.comb[l, 1], fc2 = list.comb[l, 2], seed = seed, nstartR = nstartR)

    list(res)
  }

  snow::stopCluster(cluster)
  foreach::registerDoSEQ()

  return(list(model = "CWM with Factor Y",
              results = results,
              k = k,
              fc1 = fc1,
              fc2 = fc2
  ))
}
