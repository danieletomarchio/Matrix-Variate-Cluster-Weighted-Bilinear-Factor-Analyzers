#' Selection of the best fitting model(s)
#'
#' This functions extracts the best fitting model(s) according to different information criteria.
#'
#' @param results The output of a fitting function.
#' @param sp Numeric threshold defining the minimum allowable mixture weight for each cluster, used to avoid potential spurious solutions. When set to 0, the constraint is disabled.
#'
#' @return A list containing the required best fitting model(s).
#' @export
#'
extract.bestM <- function(results, sp = 0.05) {

  k <- length(results$k)
  num.mod <- length(results[["Results"]][[1]][[1]])
  list.comb2 <- data.frame(results[[6]])
  colnames(list.comb2) <- c("fc1","fc2","k")
  nmod <- nrow(list.comb2)

  list.comb2$AIC <- rep(NA, nmod)
  list.comb2$BIC <- rep(NA, nmod)
  list.comb2$ICL <- rep(NA, nmod)

  df_repeated <- list.comb2[rep(1:nrow(list.comb2), each = num.mod), ]

  df_repeated$id <- rep(1:num.mod, times = nrow(list.comb2))
  cont <- 0

  for (i in 1:nmod) {
    for (j in 1:num.mod) {

      cont <- cont + 1

      if(length(results[["Results"]][[i]][[1]][[j]]) > 1){
        if(any(results[["Results"]][[i]][[1]][[j]]$prior < sp)){
          df_repeated[cont, 4] <- NA
          df_repeated[cont, 5] <- NA
          df_repeated[cont, 6] <- NA
        }else{
          df_repeated[cont, 4] <- tryCatch(results[["Results"]][[i]][[1]][[j]]$AIC, error = function(e) {NA})
          df_repeated[cont, 5] <- tryCatch(results[["Results"]][[i]][[1]][[j]]$BIC, error = function(e) {NA})
          df_repeated[cont, 6] <- tryCatch(results[["Results"]][[i]][[1]][[j]]$ICL, error = function(e) {NA})
        }
      }

    }
  }

  winAIC  <- df_repeated[which.min(df_repeated$AIC), ]
  winBIC  <- df_repeated[which.min(df_repeated$BIC), ]
  winICL  <- df_repeated[which.min(df_repeated$ICL), ]

  bestAIC <- results[["Results"]][[trunc(as.numeric(rownames(winAIC)))]][[1]][[winAIC$id]]
  bestBIC <- results[["Results"]][[trunc(as.numeric(rownames(winBIC)))]][[1]][[winBIC$id]]
  bestICL <- results[["Results"]][[trunc(as.numeric(rownames(winICL)))]][[1]][[winICL$id]]

  return(list(bestAIC = bestAIC, bestBIC = bestBIC, bestICL = bestICL))
}
