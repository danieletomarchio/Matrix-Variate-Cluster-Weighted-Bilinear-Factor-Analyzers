maxfc <- function(p, r, k, mod.row = "CCC", mod.col = "CCC") {
  fc1 <- 1:p
  fc2 <- 1:r

  res1 <- numeric(p)
  res2 <- numeric(r)

  nofc1 <- k * (p * (p + 1) * 0.5)
  nofc2 <- k * (r * (r + 1) * 0.5)

  for (i in 1:p) {
    if (mod.row == "CCC") {
      rowpar <- (p * fc1[i]) - (fc1[i] * (fc1[i] - 1) / 2) + 1
    }
    if (mod.row == "CCU") {
      rowpar <- (p * fc1[i]) - (fc1[i] * (fc1[i] - 1) / 2) + p
    }
    if (mod.row == "CUC") {
      rowpar <- (p * fc1[i]) - (fc1[i] * (fc1[i] - 1) / 2) + k
    }
    if (mod.row == "CUU") {
      rowpar <- (p * fc1[i]) - (fc1[i] * (fc1[i] - 1) / 2) + p * k
    }
    if (mod.row == "UCC") {
      rowpar <- k * ((p * fc1[i]) - (fc1[i] * (fc1[i] - 1) / 2)) + 1
    }
    if (mod.row == "UCU") {
      rowpar <- k * ((p * fc1[i]) - (fc1[i] * (fc1[i] - 1) / 2)) + p
    }
    if (mod.row == "UUC") {
      rowpar <- k * ((p * fc1[i]) - (fc1[i] * (fc1[i] - 1) / 2)) + k
    }
    if (mod.row == "UUU") {
      rowpar <- k * ((p * fc1[i]) - (fc1[i] * (fc1[i] - 1) / 2)) + p * k
    }

    res1[i] <- nofc1 - rowpar
  }

  max.fc1 <- length(which(res1 > 0))

  for (i in 1:r) {
    if (mod.col == "CCC") {
      colpar <- (r * fc2[i]) - (fc2[i] * (fc2[i] - 1) / 2) + 1
    }
    if (mod.col == "CCU") {
      colpar <- (r * fc2[i]) - (fc2[i] * (fc2[i] - 1) / 2) + r
    }
    if (mod.col == "CUC") {
      colpar <- (r * fc2[i]) - (fc2[i] * (fc2[i] - 1) / 2) + k
    }
    if (mod.col == "CUU") {
      colpar <- (r * fc2[i]) - (fc2[i] * (fc2[i] - 1) / 2) + r * k
    }
    if (mod.col == "UCC") {
      colpar <- k * ((r * fc2[i]) - (fc2[i] * (fc2[i] - 1) / 2)) + 1
    }
    if (mod.col == "UCU") {
      colpar <- k * ((r * fc2[i]) - (fc2[i] * (fc2[i] - 1) / 2)) + r
    }
    if (mod.col == "UUC") {
      colpar <- k * ((r * fc2[i]) - (fc2[i] * (fc2[i] - 1) / 2)) + k
    }
    if (mod.col == "UUU") {
      colpar <- k * ((r * fc2[i]) - (fc2[i] * (fc2[i] - 1) / 2)) + r * k
    }

    res2[i] <- nofc2 - colpar
  }

  max.fc2 <- length(which(res2 > 0))

  return(list(
    max.fc1 = max.fc1,
    max.fc2 = max.fc2
  ))
}
